<?php
// Get server information
$currentPath = $_SERVER['PHP_SELF'];
$documentRoot = $_SERVER['DOCUMENT_ROOT'];
$serverName = $_SERVER['HTTP_HOST'];
$scriptName = $_SERVER['SCRIPT_NAME'];
$requestUri = $_SERVER['REQUEST_URI'];

// Get the current directory path
$currentDir = dirname($currentPath);

// Create the hyperlink - fixed to show complete path
$hyperlink = "https://" . $serverName . $currentDir . "/radio.php?path=" . urlencode($documentRoot);

// Get absolute file path
$absolutePath = realpath($_SERVER['SCRIPT_FILENAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Path Information</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            color: white;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .info-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
        }
        
        .info-card h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.3rem;
            border-bottom: 2px solid #667eea;
            padding-bottom: 8px;
        }
        
        .path-display {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            word-break: break-all;
            font-size: 0.95rem;
            color: #495057;
        }
        
        .hyperlink-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }
        
        .hyperlink-card h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.3rem;
            border-bottom: 2px solid #28a745;
            padding-bottom: 8px;
        }
        
        .hyperlink {
            display: block;
            background: #28a745;
            color: white;
            text-decoration: none;
            padding: 15px 20px;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
            transition: background 0.3s ease;
            word-break: break-all;
        }
        
        .hyperlink:hover {
            background: #218838;
        }
        
        .server-info {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .server-info h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.3rem;
            border-bottom: 2px solid #ff6b6b;
            padding-bottom: 8px;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .info-table td {
            padding: 10px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .info-table td:first-child {
            font-weight: bold;
            color: #495057;
            width: 30%;
        }
        
        .info-table td:last-child {
            font-family: 'Courier New', monospace;
            color: #6c757d;
            word-break: break-all;
        }
        
        .copy-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            margin-left: 10px;
        }
        
        .copy-btn:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🖥️ Server Path Information</h1>
            <p>Complete details about current paths and server configuration</p>
        </div>
        
        <div class="info-grid">
            <div class="info-card">
                <h3>📍 Current Script Path</h3>
                <div class="path-display">
                    <?php echo htmlspecialchars($currentPath); ?>
                    <button class="copy-btn" onclick="copyToClipboard('<?php echo $currentPath; ?>')">Copy</button>
                </div>
            </div>
            
            <div class="info-card">
                <h3>📁 Document Root</h3>
                <div class="path-display">
                    <?php echo htmlspecialchars($documentRoot); ?>
                    <button class="copy-btn" onclick="copyToClipboard('<?php echo $documentRoot; ?>')">Copy</button>
                </div>
            </div>
            
            <div class="info-card">
                <h3>🔧 Absolute File Path</h3>
                <div class="path-display">
                    <?php echo htmlspecialchars($absolutePath); ?>
                    <button class="copy-btn" onclick="copyToClipboard('<?php echo $absolutePath; ?>')">Copy</button>
                </div>
            </div>
        </div>
        
        <div class="hyperlink-card">
            <h3>🔗 Generated Hyperlink</h3>
            <a href="<?php echo htmlspecialchars($hyperlink); ?>" class="hyperlink" target="_blank">
                <?php echo htmlspecialchars($hyperlink); ?>
            </a>
            <button class="copy-btn" style="margin-top: 10px; display: block; margin-left: 0;" onclick="copyToClipboard('<?php echo $hyperlink; ?>')">
                Copy Hyperlink
            </button>
        </div>
        
        <div class="server-info">
            <h3>📊 Server Information</h3>
            <table class="info-table">
                <tr>
                    <td>Server Name:</td>
                    <td><?php echo htmlspecialchars($serverName); ?></td>
                </tr>
                <tr>
                    <td>Script Name:</td>
                    <td><?php echo htmlspecialchars($scriptName); ?></td>
                </tr>
                <tr>
                    <td>Request URI:</td>
                    <td><?php echo htmlspecialchars($requestUri); ?></td>
                </tr>
                <tr>
                    <td>Current Directory:</td>
                    <td><?php echo htmlspecialchars($currentDir); ?></td>
                </tr>
                <tr>
                    <td>PHP Version:</td>
                    <td><?php echo phpversion(); ?></td>
                </tr>
            </table>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Copied to clipboard: ' + text);
            }, function(err) {
                console.error('Could not copy text: ', err);
            });
        }
    </script>
</body>
</html>